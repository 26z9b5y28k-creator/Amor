SITE ROMÂNTICO — PARA O MEU AMOR

Abra index.html no navegador. A pasta assets contém as cinco fotos enviadas.
O site funciona sem servidor e é responsivo para celular e computador.
O botão de som cria um ambiente musical simples usando Web Audio; não usa nenhuma música protegida.
