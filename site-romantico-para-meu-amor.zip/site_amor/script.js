const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
window.addEventListener('load',()=>setTimeout(()=>$('#loader').classList.add('done'),600));

const glow=$('.cursor-glow');
window.addEventListener('pointermove',e=>{glow.style.left=e.clientX+'px';glow.style.top=e.clientY+'px'});

$('#enterBtn').onclick=()=>$('#fotos').scrollIntoView({behavior:'smooth'});
$('#revealBtn').onclick=()=>{const s=$('#surprise');s.hidden=false;s.scrollIntoView({behavior:'smooth',block:'center'});burst(18)};

function burst(n=12){
  for(let i=0;i<n;i++){const p=document.createElement('span');p.className='petal';p.style.left=Math.random()*100+'%';p.style.animationDuration=(3+Math.random()*4)+'s';p.style.animationDelay=Math.random()*.7+'s';p.style.transform=`rotate(${Math.random()*360}deg)`;$('.petals').appendChild(p);setTimeout(()=>p.remove(),8000)}
}

$$('.photo-card:not(.note-card)').forEach(card=>card.addEventListener('click',()=>{
  const img=card.querySelector('img');$('#lightboxImg').src=img.src;$('#lightboxImg').alt=img.alt;$('#lightbox').classList.add('open');
}));
$('#lightboxClose').onclick=()=>$('#lightbox').classList.remove('open');
$('#lightbox').onclick=e=>{if(e.target.id==='lightbox')$('#lightbox').classList.remove('open')};

const modal=$('#reasonModal');
$$('.reason').forEach((b,i)=>b.onclick=()=>{$('#modalNumber').textContent=String(i+1).padStart(2,'0');$('#modalMessage').textContent=b.dataset.message;modal.classList.add('open');burst(7)});
$('#modalClose').onclick=()=>modal.classList.remove('open');
$('.modal-backdrop').onclick=()=>modal.classList.remove('open');

const letterText=window.LETTER.trim().split(/\n\s*\n/);
$('#letterText').innerHTML=letterText.map((p,i)=>`<p>${p.replace(/\n/g,'<br>')}</p>`).join('');
const letter=$('#letterText');
window.addEventListener('scroll',()=>{
  const rect=letter.getBoundingClientRect(), total=letter.offsetHeight-window.innerHeight;
  const passed=Math.min(Math.max(window.innerHeight-rect.top,0),letter.offsetHeight);
  $('#readProgress').textContent=Math.round((passed/letter.offsetHeight)*100)+'%';
},{passive:true});

const words=['cuidado','riso','paz','carinho','futuro','amor','nós'];
const sky=$('#sky'), bank=$('#wordBank');
const positions=[[16,25],[34,17],[55,28],[73,20],[25,61],[52,68],[76,61]];
words.forEach((word,i)=>{
  const s=document.createElement('button');s.className='star';s.title='descobrir';s.style.left=positions[i][0]+'%';s.style.top=positions[i][1]+'%';s.dataset.word=word;
  s.onclick=()=>{
    if(s.classList.contains('found'))return;
    s.classList.add('found');const w=document.createElement('span');w.className='word';w.textContent=word;bank.appendChild(w);burst(3);
    if($$('.star.found').length===words.length){const done=document.createElement('span');done.className='word';done.textContent='♡ nosso universo';bank.appendChild(done);burst(30)}
  };sky.appendChild(s);
});

let audioCtx=null, gain=null, timer=null;
$('#soundBtn').onclick=()=>{
  if(!audioCtx){audioCtx=new (window.AudioContext||window.webkitAudioContext)();gain=audioCtx.createGain();gain.gain.value=.018;gain.connect(audioCtx.destination);startAmbient();$('#soundBtn').innerHTML='♪ <span>ligado</span>'}
  else if(audioCtx.state==='running'){audioCtx.suspend();$('#soundBtn').innerHTML='♪ <span>som</span>'}
  else{audioCtx.resume();$('#soundBtn').innerHTML='♪ <span>ligado</span>'}
};
function startAmbient(){
  const notes=[196,246.94,293.66,392];
  let idx=0;
  timer=setInterval(()=>{
    if(audioCtx.state!=='running')return;
    const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='sine';o.frequency.value=notes[idx++%notes.length];g.gain.setValueAtTime(0,audioCtx.currentTime);g.gain.linearRampToValueAtTime(.018,audioCtx.currentTime+.08);g.gain.exponentialRampToValueAtTime(.0001,audioCtx.currentTime+2.5);o.connect(g);g.connect(gain);o.start();o.stop(audioCtx.currentTime+2.6);
  },1700);
}

$('#finalBtn').onclick=()=>{burst(45);$('#finale').scrollIntoView({behavior:'smooth'});};
$('#replayBtn').onclick=()=>{window.scrollTo({top:0,behavior:'smooth'});burst(20)};

const obs=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.style.animation='fadeUp .9s both'}),{threshold:.08});
$$('.section').forEach(el=>obs.observe(el));
